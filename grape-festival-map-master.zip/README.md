# Grape map

## Install
```
npm install http-server -g
```

## Run

```
http-server -p 2223 -c-1
```

and visit

```
localhost:2223
```
